import styled from 'styled-components';

const Section = styled.section``;

export default Section;
