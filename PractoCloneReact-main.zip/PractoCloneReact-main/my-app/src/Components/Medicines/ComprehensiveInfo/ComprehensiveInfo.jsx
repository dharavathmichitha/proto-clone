import "./ComprehensiveInfo.css";


export const ComprehensiveInfo = () => {
    return(
        <div id="ComprehensiveInfo">
            <div id="ComprehensiveInfoDiv">
                <img src="https://www.practostatic.com/ecommerce-assets/static/media/home/desktop/full-width-4.2a2a16cc.png" alt="" />
            </div>
        </div>
    )
}