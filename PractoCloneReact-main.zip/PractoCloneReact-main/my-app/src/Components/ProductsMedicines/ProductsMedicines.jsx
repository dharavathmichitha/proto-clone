import MedicineSearch from "../MedicineSearch/MedicineSearch";
import MedicinesProduct from "../MedicinesProduct/MedicinesProduct";

import React from 'react'

export default function ProductsMedicines() {
  return (
    <div id="prodmed">
        <MedicineSearch/>
      <MedicinesProduct/>
      
    </div>
  )
}
