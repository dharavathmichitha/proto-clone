
import style from "../VideoConsult/Styles/Faq.module.css"

export const Health = ()=>{

return(

<div className={style.section}>
    <div className={style.wrap}>
<h1 className={style.heading}>Health Queries</h1>
<div className={style.container}>

<div className={style.row}>
<section className={style.col}>
    <h3 className={style.bigtext2}>Difference Between</h3>

    <p className={style.textsub}>
        <span>What is difference between somatization disorder and Fibromyalgia ??? Do both ha... </span>
        <a href="/#"> Read More</a>
    </p>
</section>
<section className={style.col}>
    <h3 className={style.bigtext2}>Beeding after mtp</h3>

    <p className={style.textsub}>
        <span>My wife had mtp by pills exactly 15 days before, for the last 2 days there were ... </span>
        <a href="/#"> Read More</a>
    </p>
</section>




</div>




</div>


</div>

</div>








)




}